/* Sauvegarde : copie la base (cohérente), les images envoyées et les CV dans backups/AAAA-MM-JJ_HHMM/.
   Usage : npm run backup   (à planifier chaque nuit avec cron, puis à copier hors du serveur) */
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const data = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
const dbFile = path.join(data, 'servea.db');
if (!fs.existsSync(dbFile)) { console.error('Base introuvable :', dbFile); process.exit(1); }
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').slice(0, 13);
const out = path.resolve(process.env.BACKUP_DIR || path.join(root, 'backups'), stamp);
fs.mkdirSync(out, { recursive: true });
const db = new DatabaseSync(dbFile);
db.exec(`VACUUM INTO '${path.join(out, 'servea.db').replace(/'/g, "''")}'`);
db.close();
for (const d of ['uploads', 'private']) if (fs.existsSync(path.join(data, d))) fs.cpSync(path.join(data, d), path.join(out, d), { recursive: true });
console.log('Sauvegarde créée :', out);
