/* Test de bout en bout : démarre le serveur sur une base temporaire et vérifie pages, formulaires, sécurité et administration.
   Lancer : npm test */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'servea-test-'));
process.env.DATA_DIR = tmp;
process.env.ADMIN_EMAIL = 'test@servea.local';
process.env.ADMIN_PASSWORD = 'MotDePasseTest-2026';
process.env.SITE_URL = 'https://exemple.test';
process.env.PORT = '0';
const { server } = await import('../server.js');
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;

let pass = 0;
const ok = (name, fn) => Promise.resolve().then(fn).then(() => { pass++; console.log('  ✓', name); }, (e) => { console.error('  ✗', name, '\n   ', e.message); process.exitCode = 1; });
const get = (p, opt = {}) => fetch(base + p, { redirect: 'manual', ...opt });
const text = async (p, opt) => { const r = await get(p, opt); return [r, await r.text()]; };
const tokenOf = (html) => /name="_t" value="([^"]+)"/.exec(html)[1];
const form = (o) => new URLSearchParams(o).toString();
const post = (p, body, headers = {}) => get(p, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', origin: base, ...headers }, body });
function multipart(fields, files = {}) {
  const b = '----t' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields)) parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  for (const [k, f] of Object.entries(files)) { parts.push(Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="${k}"; filename="${f.name}"\r\nContent-Type: application/octet-stream\r\n\r\n`)); parts.push(f.data); parts.push(Buffer.from('\r\n')); }
  parts.push(Buffer.from(`--${b}--\r\n`));
  return { body: Buffer.concat(parts), headers: { 'content-type': `multipart/form-data; boundary=${b}`, origin: base } };
}

console.log('Pages publiques');
const pages = ['/', '/a-propos', '/services', '/services/home-personal-services', '/services/technical-maintenance', '/services/business-services', '/services/events-staffing', '/secteurs', '/carrieres', '/devis', '/contact', '/actualites', '/mentions-legales', '/confidentialite',
  '/en/', '/en/about', '/en/services', '/en/services/events-staffing', '/en/sectors', '/en/careers', '/en/quote', '/en/contact', '/en/news', '/en/legal', '/en/privacy', '/robots.txt', '/sitemap.xml'];
for (const p of pages) await ok(`GET ${p} → 200`, async () => { const r = await get(p); assert.equal(r.status, 200); });
await ok('404 propre', async () => { const [r, h] = await text('/inexistant'); assert.equal(r.status, 404); assert.match(h, /Page introuvable/); });
await ok('actualité en brouillon invisible', async () => assert.equal((await get('/actualites/bienvenue-sur-le-site-de-servea')).status, 404));
await ok('accueil : titre du cahier des charges + SEO + hreflang', async () => {
  const [, h] = await text('/');
  assert.match(h, /Des solutions adaptées à chaque besoin\./); assert.match(h, /<meta name="description"/); assert.match(h, /hreflang="en" href="https:\/\/exemple\.test\/en\/"/); assert.match(h, /application\/ld\+json/);
});
await ok('version anglaise', async () => { const [, h] = await text('/en/'); assert.match(h, /lang="en"/); assert.match(h, /Solutions tailored to every need\./); });
await ok('aucune coordonnée inventée : « À renseigner » affiché', async () => { const [, h] = await text('/contact'); assert.match(h, /À renseigner/); assert.doesNotMatch(h, /wa\.me/); });
await ok('tarifs de la plaquette affichés', async () => { const [, h] = await text('/services/home-personal-services'); assert.match(h, /350 USD\/mois/); });
await ok('liens internes de la page d\'accueil valides', async () => {
  const [, h] = await text('/');
  const links = [...new Set([...h.matchAll(/href="(\/[^"#?]*)/g)].map((m) => m[1]))].filter((l) => !/^\/(img|css|js)\//.test(l));
  for (const l of links) assert.equal((await get(l)).status, 200, `lien cassé : ${l}`);
});
await ok('en-têtes de sécurité', async () => { const r = await get('/'); assert.ok(r.headers.get('content-security-policy')); assert.equal(r.headers.get('x-frame-options'), 'DENY'); assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); });
await ok('traversée de répertoire bloquée', async () => { for (const p of ['/img/../server.js', '/img/%2e%2e/server.js', '/uploads/..%2f.secret', '/uploads/../.secret']) { const r = await get(p); assert.ok([400, 404].includes(r.status), p + ' → ' + r.status); } });
await ok('base de données non exposée', async () => assert.equal((await get('/data/servea.db')).status, 404));

console.log('Formulaires');
const [, qhtml] = await text('/devis');
const qtok = tokenOf(qhtml);
const [, chtml] = await text('/contact');
const ctok = tokenOf(chtml);
const [, jhtml] = await text('/carrieres');
const jtok = tokenOf(jhtml);
await new Promise((r) => setTimeout(r, 2700));
const goodQuote = { _t: qtok, website: '', client_type: 'entreprise', name: 'Jean Test', company: 'ACME', phone: '+243 810 000 000', email: 'jean@example.com', pole: 'business-services', service: 'nettoyage-entreprise', location: 'Gombe, Kinshasa', date_wanted: '2030-01-15', need: 'Nettoyage mensuel de nos bureaux.' };
await ok('devis : validation (e-mail invalide, champs vides) → 422', async () => { const r = await post('/devis', form({ ...goodQuote, email: 'pas-un-email', need: '' })); assert.equal(r.status, 422); const h = await r.text(); assert.match(h, /Adresse e-mail invalide/); assert.match(h, /Champ obligatoire/); assert.match(h, /value="Jean Test"/); });
await ok('devis : sans jeton anti-spam → refusé', async () => { const r = await post('/devis', form({ ...goodQuote, _t: '' })); assert.equal(r.status, 422); assert.match(await r.text(), /anti-spam/); });
await ok('devis : pot de miel → rien enregistré', async () => { const r = await post('/devis', form({ ...goodQuote, website: 'http://spam.example' })); assert.equal(r.status, 303); });
await ok('devis : valide → confirmation', async () => { const r = await post('/devis', form(goodQuote)); assert.equal(r.status, 303); assert.match(r.headers.get('location'), /envoye=1/); const [, h] = await text(r.headers.get('location')); assert.match(h, /Demande envoyée/); });
await ok('devis : origine étrangère refusée', async () => { const r = await post('/devis', form(goodQuote), { origin: 'https://evil.example' }); assert.equal(r.status, 403); });
await ok('contact : valide', async () => { const r = await post('/contact', form({ _t: ctok, website: '', name: 'Awa', email: 'awa@example.com', phone: '', subject: 'Question', body: 'Bonjour, une question <b>importante</b>.' })); assert.equal(r.status, 303); });
const cv = { name: 'cv.pdf', data: Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n') };
const app = { _t: jtok, website: '', last_name: 'Mbuyi', first_name: 'Grace', phone: '0990000000', email: 'grace@example.com', city: 'Kinshasa', position: 'Nounou / baby-sitter', experience: '5 ans', presentation: 'Sérieuse et motivée.' };
await ok('candidature : fichier exécutable refusé', async () => { const m = multipart(app, { cv: { name: 'virus.pdf', data: Buffer.from('MZ\x90\x00\x03 binaire exécutable ...........') } }); const r = await post('/carrieres', m.body, m.headers); assert.equal(r.status, 422); assert.match(await r.text(), /Fichier non accepté/); });
await ok('candidature : valide avec CV', async () => { const m = multipart(app, { cv }); const r = await post('/carrieres', m.body, m.headers); assert.equal(r.status, 303); });
await ok('candidature : fichier de 6 Mo refusé', async () => { const m = multipart(app, { cv: { name: 'gros.pdf', data: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(6 * 1024 * 1024)]) } }); const r = await post('/carrieres', m.body, m.headers); assert.equal(r.status, 422); });
await ok('limitation de débit des formulaires', async () => { let last; for (let i = 0; i < 8; i++) last = await post('/contact', form({ _t: ctok, name: 'x', email: 'x@y.co', subject: 's', body: 'b' })); assert.equal(last.status, 422); assert.match(await last.text(), /Trop de demandes/); });

console.log('Administration');
await ok('admin protégé sans connexion', async () => { for (const p of ['/admin', '/admin/quotes', '/admin/settings', '/admin/cv/1']) { const r = await get(p); assert.equal(r.status, 303); assert.match(r.headers.get('location'), /\/admin\/login/); } });
await ok('connexion refusée avec mauvais mot de passe', async () => { const r = await post('/admin/login', form({ email: 'test@servea.local', password: 'faux' })); assert.equal(r.status, 401); });
let cookie = '';
await ok('connexion réussie (cookie HttpOnly, SameSite=Strict)', async () => { const r = await post('/admin/login', form({ email: 'test@servea.local', password: process.env.ADMIN_PASSWORD })); assert.equal(r.status, 303); const c = r.headers.get('set-cookie'); assert.match(c, /HttpOnly/); assert.match(c, /SameSite=Strict/); cookie = c.split(';')[0]; });
const A = (p, opt = {}) => get(p, { ...opt, headers: { cookie, ...(opt.headers || {}) } });
const csrfOf = async (p) => /name="_csrf" value="([^"]+)"/.exec(await (await A(p)).text())[1];
await ok('tableau de bord : statistiques', async () => { const h = await (await A('/admin')).text(); assert.match(h, /Demandes de devis/); assert.match(h, /Services publiés/); assert.match(h, /Candidatures/); });
await ok('devis visible dans l\'administration', async () => { const h = await (await A('/admin/quotes')).text(); assert.match(h, /Jean Test/); const d = await (await A('/admin/quotes/1')).text(); assert.match(d, /Nettoyage mensuel/); assert.match(d, /Gombe, Kinshasa/); });
await ok('message : contenu échappé (pas de HTML injecté)', async () => { const h = await (await A('/admin/messages/1')).text(); assert.match(h, /&lt;b&gt;importante&lt;\/b&gt;/); assert.doesNotMatch(h, /<b>importante/); });
await ok('candidature + téléchargement du CV', async () => { const h = await (await A('/admin/applications/1')).text(); assert.match(h, /Grace Mbuyi/); const r = await A('/admin/cv/1'); assert.equal(r.status, 200); assert.equal(r.headers.get('content-type'), 'application/pdf'); assert.equal((await r.text()).slice(0, 4), '%PDF'); });
await ok('CV non accessible publiquement', async () => { assert.equal((await get('/admin/cv/1')).status, 303); assert.equal((await get('/private/cv/x.pdf')).status, 404); });
await ok('export CSV', async () => { const r = await A('/admin/quotes.csv'); assert.match(r.headers.get('content-type'), /csv/); assert.match(await r.text(), /Jean Test/); });
await ok('POST admin sans jeton CSRF → 403', async () => { const r = await post('/admin/settings', form({ phone: '123' }), { cookie }); assert.equal(r.status, 403); });
await ok('changement de statut d\'un devis', async () => { const t = await csrfOf('/admin/quotes/1'); const r = await post('/admin/quotes/1', form({ _csrf: t, status: 'traité', note: 'Rappelé' }), { cookie }); assert.equal(r.status, 303); assert.match(await (await A('/admin/quotes/1')).text(), /Rappelé/); });
await ok('modification des coordonnées → visibles sur le site + bouton WhatsApp', async () => {
  const t = await csrfOf('/admin/settings');
  const m = multipart({ _csrf: t, phone: '+243 800 111 222', email: 'contact@servea.test', address: 'Avenue Test 1, Gombe, Kinshasa', whatsapp: '+243 800 111 222', hero_title_fr: 'Nouveau titre accueil', hero_title_en: 'New hero title', show_prices: '1', facebook: 'facebook.com/servea', ga_id: 'G-TEST12345', map_embed: 'https://www.google.com/maps/embed?pb=abc' });
  const r = await post('/admin/settings', m.body, { ...m.headers, cookie }); assert.equal(r.status, 303);
  const [, c] = await text('/contact'); assert.match(c, /Avenue Test 1/); assert.match(c, /wa\.me\/243800111222/); assert.match(c, /google\.com\/maps\/embed/);
  const [, hm] = await text('/'); assert.match(hm, /Nouveau titre accueil/); assert.match(hm, /facebook\.com\/servea/); assert.match(hm, /analytics\.js/);
  const [, en] = await text('/en/'); assert.match(en, /New hero title/);
  assert.match(await (await get('/js/analytics.js')).text(), /G-TEST12345/);
});
await ok('masquer les tarifs', async () => { const t = await csrfOf('/admin/settings'); const m = multipart({ _csrf: t }); await post('/admin/settings', m.body, { ...m.headers, cookie }); const [, h] = await text('/services/home-personal-services'); assert.doesNotMatch(h, /350 USD/); });
await ok('ajouter un service depuis l\'admin', async () => {
  const t = await csrfOf('/admin/services/new');
  const m = multipart({ _csrf: t, pole_id: '2', name_fr: 'Climatisation', name_en: 'Air conditioning', slug: '', category: 'Installation', desc_fr: 'Installation de climatiseurs.', desc_en: '', benefits_fr: 'Intervention rapide', benefits_en: '', price_fr: '', price_en: '', image: '', position: '9', published: '1' });
  const r = await post('/admin/services/new', m.body, { ...m.headers, cookie }); assert.equal(r.status, 303);
  const [, h] = await text('/services/technical-maintenance'); assert.match(h, /Climatisation/); assert.match(h, /Installation de climatiseurs/);
});
await ok('dépublier un service le retire du site', async () => { const t = await csrfOf('/admin/services/new'); const id = /\/admin\/services\/(\d+)/.exec(await (await A('/admin/services')).text().then((x) => x.match(/href="\/admin\/services\/(\d+)"[^>]*><strong>Climatisation/) ? x.match(/href="\/admin\/services\/(\d+)"[^>]*><strong>Climatisation/)[0] : ''))[1];
  const m = multipart({ _csrf: t, pole_id: '2', name_fr: 'Climatisation', name_en: '', slug: 'climatisation', category: '', desc_fr: '', desc_en: '', benefits_fr: '', benefits_en: '', price_fr: '', price_en: '', image: '', position: '9' });
  await post('/admin/services/' + id, m.body, { ...m.headers, cookie }); const [, h] = await text('/services/technical-maintenance'); assert.doesNotMatch(h, /Climatisation/); });
await ok('publier une actualité', async () => {
  const t = await csrfOf('/admin/news/new');
  const m = multipart({ _csrf: t, title_fr: 'Ouverture de notre site', title_en: '', slug: '', excerpt_fr: 'Résumé', excerpt_en: '', body_fr: 'Premier paragraphe.\n\nSecond paragraphe.', body_en: '', image: '', published: '1' });
  await post('/admin/news/new', m.body, { ...m.headers, cookie });
  const [r, h] = await text('/actualites/ouverture-de-notre-site'); assert.equal(r.status, 200); assert.match(h, /Second paragraphe/); assert.match((await text('/sitemap.xml'))[1], /ouverture-de-notre-site/);
});
await ok('téléversement d\'image : type vérifié par signature', async () => {
  const t = await csrfOf('/admin/news/new');
  const bad = multipart({ _csrf: t, title_fr: 'X', image: '' }, { image__file: { name: 'a.jpg', data: Buffer.from('<script>alert(1)</script>............') } });
  const r1 = await post('/admin/news/new', bad.body, { ...bad.headers, cookie }); assert.equal(r1.status, 200); assert.match(await r1.text(), /Image refusée/);
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(40)]);
  const good = multipart({ _csrf: t, title_fr: 'Avec image', image: '', published: '1' }, { image__file: { name: 'a.png', data: png } });
  const r2 = await post('/admin/news/new', good.body, { ...good.headers, cookie }); assert.equal(r2.status, 303);
  const h = await (await get('/actualites')).text(); const src = /src="(\/uploads\/[^"]+\.png)"/.exec(h)[1]; assert.equal((await get(src)).status, 200);
});
await ok('un pôle contenant des services ne peut pas être supprimé', async () => { const t = await csrfOf('/admin/poles/1'); const r = await post('/admin/poles/1/delete', form({ _csrf: t }), { cookie }); assert.match(r.headers.get('location'), /m=!/); assert.equal((await get('/services/home-personal-services')).status, 200); });
await ok('changement du mot de passe', async () => {
  const t = await csrfOf('/admin/account');
  const bad = await post('/admin/account', form({ _csrf: t, current: 'mauvais', next: 'NouveauMotDePasse-1', next2: 'NouveauMotDePasse-1' }), { cookie }); assert.match(await bad.text(), /incorrect/);
  const r = await post('/admin/account', form({ _csrf: t, current: process.env.ADMIN_PASSWORD, next: 'NouveauMotDePasse-1', next2: 'NouveauMotDePasse-1' }), { cookie }); assert.equal(r.status, 303);
  assert.equal((await post('/admin/login', form({ email: 'test@servea.local', password: 'NouveauMotDePasse-1' }))).status, 303);
});
await ok('déconnexion', async () => { const t = await csrfOf('/admin'); const r = await post('/admin/logout', form({ _csrf: t }), { cookie }); assert.match(r.headers.get('set-cookie'), /Max-Age=0/); });
await ok('verrouillage après trop de tentatives de connexion', async () => { let r; for (let i = 0; i < 10; i++) r = await post('/admin/login', form({ email: 'x@y.co', password: 'nope' })); assert.equal(r.status, 429); });

server.close();
fs.rmSync(tmp, { recursive: true, force: true });
console.log(process.exitCode ? '\nÉCHEC' : `\n${pass} tests réussis`);
process.exit(process.exitCode || 0);
