/* SERVEA : interactions du site public (menu mobile, animations, formulaires). Le site reste fonctionnel sans JavaScript. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  root.classList.add('js');

  /* En-tête : ombre au défilement */
  var header = d.querySelector('.site-header');
  function onScroll() { if (header) header.classList.toggle('scrolled', window.scrollY > 8); }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

  /* Menu mobile */
  var btn = d.querySelector('.menu-btn'), nav = d.getElementById('main-nav');
  function setMenu(open) {
    if (!btn || !nav) return;
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    nav.classList.toggle('open', open);
    d.body.classList.toggle('nav-open', open);
  }
  if (btn && nav) {
    btn.addEventListener('click', function () { setMenu(btn.getAttribute('aria-expanded') !== 'true'); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setMenu(false); btn.focus(); } });
    window.matchMedia('(min-width: 1021px)').addEventListener('change', function () { setMenu(false); });
  }

  /* Apparition progressive */
  var items = d.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    items.forEach(function (el) { io.observe(el); });
  } else { items.forEach(function (el) { el.classList.add('in'); }); }

  /* Formulaires : anti double envoi, contrôle du fichier, focus sur les erreurs */
  d.querySelectorAll('form.form').forEach(function (form) {
    form.addEventListener('submit', function () {
      var b = form.querySelector('button[type=submit]');
      if (b) { b.disabled = true; b.style.opacity = '.7'; setTimeout(function () { b.disabled = false; b.style.opacity = ''; }, 8000); }
    });
    var file = form.querySelector('input[type=file]');
    if (file) file.addEventListener('change', function () {
      var f = file.files[0], msg = d.getElementById(file.id + '-m');
      if (f && f.size > 5 * 1024 * 1024) { file.value = ''; if (msg) msg.innerHTML = '<span class="err">5 Mo max. / 5 MB max.</span>'; }
      else if (msg) msg.textContent = '';
    });
  });
  var errs = d.getElementById('form-errors');
  if (errs) { errs.scrollIntoView({ block: 'center' }); errs.focus({ preventScroll: true }); }
})();
