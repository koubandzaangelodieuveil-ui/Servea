/* Administration SERVEA : confirmations de suppression et réduction automatique des images avant envoi. */
(function () {
  'use strict';
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
  });

  var MAX = 1600;
  document.querySelectorAll('input[type=file][data-img]').forEach(function (input) {
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type) || !window.DataTransfer) return;
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var w = img.naturalWidth, h = img.naturalHeight, big = Math.max(w, h);
        if (big <= MAX && file.size < 1.5 * 1024 * 1024) return;
        var k = Math.min(1, MAX / big), c = document.createElement('canvas');
        c.width = Math.round(w * k); c.height = Math.round(h * k);
        var ctx = c.getContext('2d');
        if (file.type !== 'image/png') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); }
        ctx.drawImage(img, 0, 0, c.width, c.height);
        var type = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        c.toBlob(function (blob) {
          if (!blob || blob.size >= file.size) return;
          var ext = type === 'image/png' ? '.png' : '.jpg';
          var dt = new DataTransfer();
          dt.items.add(new File([blob], file.name.replace(/\.\w+$/, '') + ext, { type: type }));
          input.files = dt.files;
        }, type, 0.85);
      };
      img.src = url;
    });
  });
})();
