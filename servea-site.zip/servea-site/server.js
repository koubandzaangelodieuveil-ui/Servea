import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { ROOT, DATA_DIR, PROD, SITE_URL, readBody, parseMultipart, sniff } from './lib/util.js';
import { db, seed, S } from './lib/db.js';
import { handlePublic, notFound } from './lib/pages.js';
import { handleAdmin } from './lib/admin.js';
import { ROUTES } from './lib/layout.js';

seed();

const PORT = Number(process.env.PORT) || 3000;
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const PUBLIC_DIR = path.join(ROOT, 'public');
const MIME = {
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json',
};
const COMPRESSIBLE = /^(text\/|application\/(xml|json)|image\/svg)/;

const CSP = [
  "default-src 'self'", "base-uri 'self'", "object-src 'none'", "frame-ancestors 'none'", "form-action 'self'",
  "img-src 'self' data: https://www.google-analytics.com https://*.googletagmanager.com https://*.google.com https://*.gstatic.com https://*.googleapis.com",
  "script-src 'self' https://www.googletagmanager.com", "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", "font-src 'self' https://fonts.gstatic.com",
  "connect-src 'self' https://www.google-analytics.com https://*.analytics.google.com https://*.googletagmanager.com", "frame-src https://www.google.com https://maps.google.com",
].join('; ');

function baseHeaders(extra = {}) {
  const hd = {
    'Content-Security-Policy': CSP, 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()', 'Cross-Origin-Opener-Policy': 'same-origin', ...extra,
  };
  if (PROD) hd['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  return hd;
}
function send(req, res, status, body, type, extra = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  const hd = baseHeaders({ 'Content-Type': type, Vary: 'Accept-Encoding', ...extra });
  let out = buf;
  if (COMPRESSIBLE.test(type) && buf.length > 800 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { out = zlib.gzipSync(buf, { level: 6 }); hd['Content-Encoding'] = 'gzip'; }
  hd['Content-Length'] = out.length;
  res.writeHead(status, hd);
  res.end(req.method === 'HEAD' ? undefined : out);
}
function parseCookies(h) {
  const o = {};
  for (const part of String(h || '').split(';')) { const i = part.indexOf('='); if (i > 0) o[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return o;
}
function clientIp(req) {
  if (TRUST_PROXY) { const x = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim(); if (x) return x; }
  return req.socket.remoteAddress || 'unknown';
}

function serveStatic(req, res, file, immutableQuery) {
  let st;
  try { st = fs.statSync(file); } catch { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(file).toLowerCase();
  const type = MIME[ext];
  if (!type) return false;
  const cache = file.startsWith(path.join(DATA_DIR, 'uploads')) ? 'public, max-age=604800' : immutableQuery ? 'public, max-age=2592000' : 'public, max-age=86400';
  const etag = `W/"${st.size}-${Math.floor(st.mtimeMs)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, baseHeaders({ ETag: etag, 'Cache-Control': cache })); res.end(); return true; }
  send(req, res, 200, fs.readFileSync(file), type, { ETag: etag, 'Cache-Control': cache });
  return true;
}

function sitemap() {
  const base = SITE_URL || '';
  const items = [];
  const add = (key, sub = '') => items.push({ fr: ROUTES[key].fr + (sub ? (key === 'home' ? '' : '/') + sub : ''), en: ROUTES[key].en + (sub ? '/' + sub : '') });
  ['home', 'about', 'services', 'sectors', 'careers', 'quote', 'contact', 'news', 'legal', 'privacy'].forEach((k) => add(k));
  db.prepare('SELECT slug FROM poles WHERE published=1').all().forEach((p) => add('services', p.slug));
  db.prepare('SELECT slug FROM news WHERE published=1').all().forEach((n) => add('news', n.slug));
  const x = (u) => u.replace(/&/g, '&amp;');
  const urls = items.flatMap((i) => ['fr', 'en'].map((l) => `<url><loc>${x(base + i[l])}</loc><xhtml:link rel="alternate" hreflang="fr" href="${x(base + i.fr)}"/><xhtml:link rel="alternate" hreflang="en" href="${x(base + i.en)}"/></url>`));
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">${urls.join('')}</urlset>`;
}

async function handler(req, res) {
  const u = new URL(req.url, 'http://localhost');
  let pathname;
  try { pathname = decodeURIComponent(u.pathname); } catch { return send(req, res, 400, 'Bad request', 'text/plain'); }
  if (!['GET', 'HEAD', 'POST'].includes(req.method)) return send(req, res, 405, 'Method not allowed', 'text/plain', { Allow: 'GET, HEAD, POST' });
  if (pathname.includes('\0') || pathname.includes('..')) return send(req, res, 400, 'Bad request', 'text/plain');

  /* Fichiers statiques */
  if (req.method !== 'POST') {
    if (pathname.startsWith('/uploads/') && serveStatic(req, res, path.join(DATA_DIR, 'uploads', path.basename(pathname)))) return;
    if (/^\/(img|css|js)\//.test(pathname) && serveStatic(req, res, path.join(PUBLIC_DIR, pathname), u.searchParams.has('v'))) return;
    if (pathname === '/robots.txt') {
      return send(req, res, 200, `User-agent: *\nDisallow: /admin\nAllow: /\n${SITE_URL ? `Sitemap: ${SITE_URL}/sitemap.xml\n` : ''}`, 'text/plain; charset=utf-8', { 'Cache-Control': 'public, max-age=3600' });
    }
    if (pathname === '/sitemap.xml') return send(req, res, 200, sitemap(), 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=3600' });
    if (pathname === '/favicon.ico') { if (serveStatic(req, res, path.join(PUBLIC_DIR, 'img', 'favicon.png'))) return; }
    if (pathname === '/js/analytics.js') {
      const id = S('ga_id').trim();
      const js = /^G-[A-Z0-9]{4,15}$/.test(id) ? `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${id}',{anonymize_ip:true});var s=document.createElement('script');s.async=true;s.src='https://www.googletagmanager.com/gtag/js?id=${id}';document.head.appendChild(s);` : '';
      return send(req, res, 200, js, 'text/javascript; charset=utf-8', { 'Cache-Control': 'public, max-age=600' });
    }
    if (pathname === '/healthz') return send(req, res, 200, 'ok', 'text/plain');
  }

  /* Contexte */
  const ctx = {
    req, res, method: req.method, pathname, query: u.searchParams, ip: clientIp(req), cookies: parseCookies(req.headers.cookie), lang: pathname.startsWith('/en') ? 'en' : 'fr',
    fields: {}, files: {}, redirect: (loc) => ({ redirect: loc }),
  };
  if (req.method === 'POST') {
    const ct = req.headers['content-type'] || '';
    const isAdmin = pathname.startsWith('/admin');
    const wantsFile = isAdmin || /\/(carrieres|careers)$/.test(pathname.replace(/\/+$/, ''));
    try {
      const buf = await readBody(req, wantsFile ? 9 * 1024 * 1024 : 200 * 1024);
      if (ct.startsWith('multipart/form-data')) { const mp = parseMultipart(buf, ct); ctx.fields = mp.fields; ctx.files = mp.files; }
      else if (ct.startsWith('application/x-www-form-urlencoded')) ctx.fields = Object.fromEntries(new URLSearchParams(buf.toString('utf8')));
    } catch (e) {
      return send(req, res, e.status || 400, e.status === 413 ? 'Fichier trop volumineux.' : 'Bad request', 'text/plain; charset=utf-8');
    }
    /* Origine : refuse les POST venant d'un autre site */
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) return send(req, res, 403, 'Forbidden', 'text/plain'); } catch { return send(req, res, 403, 'Forbidden', 'text/plain'); } }
  }

  let r = handleAdmin(ctx);
  if (r === null) r = handlePublic(ctx);
  if (r === null) r = notFound(ctx);

  const noStore = { 'Cache-Control': 'no-store' };
  if (r.redirect) {
    const extra = { Location: r.redirect, ...noStore };
    if (r.cookie) extra['Set-Cookie'] = r.cookie;
    res.writeHead(303, baseHeaders(extra)); return res.end();
  }
  if (r.buffer) return send(req, res, r.status || 200, r.buffer, r.type, { ...noStore, ...(r.headers || {}) });
  const isAdminPage = pathname.startsWith('/admin');
  const extra = isAdminPage || req.method === 'POST' ? noStore : { 'Cache-Control': 'public, max-age=0, must-revalidate' };
  if (r.cookie) extra['Set-Cookie'] = r.cookie;
  send(req, res, r.status || 200, r.html, r.type || 'text/html; charset=utf-8', { ...extra, ...(r.headers || {}) });
}

const server = http.createServer((req, res) => {
  handler(req, res).catch((err) => {
    console.error('[erreur]', err);
    if (!res.headersSent) send(req, res, 500, '<h1>Erreur serveur</h1><p>Une erreur est survenue. Veuillez réessayer plus tard.</p>', 'text/html; charset=utf-8');
    else res.end();
  });
});
server.requestTimeout = 30000;
server.headersTimeout = 15000;
export { server, PORT };

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname)) {
  server.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`SERVEA : site disponible sur http://localhost:${PORT}  (admin : /admin)`));
  const stop = () => { server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
