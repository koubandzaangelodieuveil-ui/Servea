/* SERVEA : interactions du site public (menu mobile, animations, formulaires). Le site reste fonctionnel sans JavaScript. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  root.classList.add('js');

  /* En-tête : ombre au défilement */
  var header = d.querySelector('.site-header');
  function onScroll() { if (header) header.classList.toggle('scrolled', window.scrollY > 8); }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

  /* Menu mobile */
  var btn = d.querySelector('.menu-btn'), nav = d.getElementById('main-nav');
  function setMenu(open) {
    if (!btn || !nav) return;
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    nav.classList.toggle('open', open);
    d.body.classList.toggle('nav-open', open);
  }
  if (btn && nav) {
    btn.addEventListener('click', function () { setMenu(btn.getAttribute('aria-expanded') !== 'true'); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setMenu(false); btn.focus(); } });
    window.matchMedia('(min-width: 1021px)').addEventListener('change', function () { setMenu(false); });
  }

  /* Apparition progressive */
  var items = d.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    items.forEach(function (el) { io.observe(el); });
  } else { items.forEach(function (el) { el.classList.add('in'); }); }

  /* Formulaires : anti double envoi, contrôle du fichier, focus sur les erreurs */
  d.querySelectorAll('form.form').forEach(function (form) {
    form.addEventListener('submit', function () {
      var b = form.querySelector('button[type=submit]');
      if (b) { b.disabled = true; b.style.opacity = '.7'; setTimeout(function () { b.disabled = false; b.style.opacity = ''; }, 8000); }
    });
    var file = form.querySelector('input[type=file]');
    if (file) file.addEventListener('change', function () {
      var f = file.files[0], msg = d.getElementById(file.id + '-m');
      if (f && f.size > 5 * 1024 * 1024) { file.value = ''; if (msg) msg.innerHTML = '<span class="err">5 Mo max. / 5 MB max.</span>'; }
      else if (msg) msg.textContent = '';
    });
  });
  var errs = d.getElementById('form-errors');
  if (errs) { errs.scrollIntoView({ block: 'center' }); errs.focus({ preventScroll: true }); }
})();

/* ===== VIBE MOTION (ajout) ===== */
(function () {
  'use strict';
  var d = document, reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;
  var raf = window.requestAnimationFrame.bind(window);

  /* Barre de progression + en-tête qui se masque en descendant */
  var bar = d.createElement('div'); bar.className = 'progress'; d.body.appendChild(bar);
  var header = d.querySelector('.site-header'), lastY = 0, ticking = false;
  function onScroll() {
    var y = window.scrollY, max = d.documentElement.scrollHeight - window.innerHeight;
    bar.style.transform = 'scaleX(' + (max > 0 ? y / max : 0) + ')';
    if (header && !d.body.classList.contains('nav-open')) header.classList.toggle('hide', y > lastY && y > 240);
    lastY = y;
    parallax(y); ticking = false;
  }
  window.addEventListener('scroll', function () { if (!ticking) { ticking = true; raf(onScroll); } }, { passive: true });

  /* Hero : mots, orbes, halo qui suit la souris */
  var hero = d.querySelector('.hero');
  if (hero) {
    d.querySelectorAll('.hero-copy > *').forEach(function (el, i) { el.style.setProperty('--i', i); });
    var h1 = hero.querySelector('h1');
    if (h1) {
      var words = h1.textContent.trim().split(/\s+/);
      h1.setAttribute('aria-label', h1.textContent.trim());
      h1.innerHTML = words.map(function (w, k) { return '<span class="w" aria-hidden="true"><span style="--k:' + k + '">' + w + '</span></span>'; }).join(' ');
    }
    ['o1', 'o2'].forEach(function (c) { var o = d.createElement('i'); o.className = 'orb ' + c; hero.insertBefore(o, hero.firstChild); });
    var glow = d.createElement('div'); glow.className = 'hero-glow'; hero.appendChild(glow);
    hero.addEventListener('pointermove', function (e) {
      var r = hero.getBoundingClientRect();
      glow.style.setProperty('--mx', (e.clientX - r.left) + 'px'); glow.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    /* Bandeau défilant (contenu repris du site : pôles + devise) */
    var names = Array.prototype.map.call(d.querySelectorAll('.pole-card h3'), function (n) { return n.textContent; });
    var motto = (d.querySelector('.hero-badge span') || {}).textContent;
    var items = names.concat(motto ? [motto] : []);
    if (items.length) {
      var html = items.map(function (t) { return '<span>' + t + '</span>'; }).join('');
      var m = d.createElement('div'); m.className = 'marquee'; m.setAttribute('aria-hidden', 'true');
      m.innerHTML = '<div class="marquee-track">' + html + html + html + html + '</div>';
      hero.insertAdjacentElement('afterend', m);
    }
  }

  /* Cascade des révélations dans les grilles */
  d.querySelectorAll('.pole-grid, .why-grid, .aud-grid, .sec-head + div').forEach(function (g) {
    Array.prototype.forEach.call(g.querySelectorAll(':scope > .reveal'), function (el, i) { el.style.setProperty('--d', (i * 0.09) + 's'); });
  });
  var collage = d.querySelector('.intro-collage');
  if (collage && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { collage.classList.add('in'); io.disconnect(); } }); }, { threshold: .2 });
    io.observe(collage);
  } else if (collage) collage.classList.add('in');

  /* Parallaxe du collage */
  var speeds = [-.06, .05, -.03];
  var imgs = collage ? collage.querySelectorAll('img') : [];
  function parallax() {
    if (!collage) return;
    var r = collage.getBoundingClientRect(), c = r.top + r.height / 2 - window.innerHeight / 2;
    Array.prototype.forEach.call(imgs, function (im, i) { im.style.setProperty('--py', (c * speeds[i % 3]).toFixed(1) + 'px'); });
  }

  /* Tilt 3D + spotlight sur les cartes (souris uniquement) */
  if (window.matchMedia('(hover: hover)').matches) {
    d.querySelectorAll('.pole-card').forEach(function (card) {
      card.classList.add('tilt');
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        card.style.transform = 'rotateY(' + ((x - .5) * 10).toFixed(2) + 'deg) rotateX(' + ((.5 - y) * 10).toFixed(2) + 'deg) translateY(-6px)';
        card.style.setProperty('--gx', (x * 100) + '%'); card.style.setProperty('--gy', (y * 100) + '%');
      });
      card.addEventListener('pointerleave', function () { card.style.transform = ''; });
    });
    /* Boutons magnétiques */
    d.querySelectorAll('.btn-lg, .cta-band .btn').forEach(function (b) {
      b.classList.add('mag');
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        b.style.transform = 'translate(' + ((e.clientX - r.left - r.width / 2) * .18).toFixed(1) + 'px,' + ((e.clientY - r.top - r.height / 2) * .28).toFixed(1) + 'px)';
      });
      b.addEventListener('pointerleave', function () { b.style.transform = ''; });
    });
  }
  onScroll();
})();
