# SERVEA : site officiel

Site web bilingue (français / anglais) de **SERVEA**, entreprise multiservices de Kinshasa, avec **espace d'administration** : l'équipe modifie les textes, les services, les photos et consulte les demandes sans développeur.

> *L'excellence est un style de vie.*

## Ce qui est inclus

| Public | Administration (`/admin`) |
|---|---|
| Accueil, À propos, Nos services (4 pôles + une page par pôle), Nos secteurs, Carrières, Demande de devis, Contact, Actualités, Mentions légales, Confidentialité | Tableau de bord (devis, candidatures, messages, services publiés) |
| Version anglaise sous `/en/…` (sélecteur de langue dans l'en-tête) | Devis, candidatures (avec téléchargement du CV) et messages : statut, note interne, export CSV |
| Formulaires réels : devis, candidature (+ CV), contact, avec validation et anti-spam | Pôles, services, profils recherchés, actualités : ajouter / modifier / supprimer / dépublier |
| SEO : titres et méta-descriptions, URL propres, `sitemap.xml`, `robots.txt`, balises `hreflang`, données structurées | Textes de l'accueil, coordonnées, réseaux sociaux, WhatsApp, Google Maps, Analytics, Search Console, mentions légales |
| Bouton WhatsApp (n'apparaît que si le numéro est renseigné) | Photographies : envoi avec réduction automatique à 1600 px |

## Technologies et coûts

Le site tourne avec **Node.js 22 seul, sans aucune dépendance** (pas de `npm install`, pas de framework à maintenir) et une base **SQLite** intégrée.

- **Frontend** : HTML rendu côté serveur, CSS et JavaScript maison (aucun framework). Le site fonctionne même sans JavaScript.
- **Backend** : Node.js (module `http` natif). **Base de données** : SQLite (`node:sqlite`), un seul fichier à sauvegarder.
- **Authentification** : mot de passe haché (scrypt), cookie signé `HttpOnly` + `SameSite=Strict`, jeton CSRF, blocage après 8 échecs.
- **Coût** : aucun logiciel payant. Seuls coûts : l'hébergement (un petit serveur/VPS ou une offre avec disque persistant : de l'ordre de quelques dollars par mois, tarifs à vérifier chez l'hébergeur) et le nom de domaine. Google Analytics et Search Console sont gratuits.

## Démarrage en local

```bash
node --version            # 22.13 ou plus récent
cp .env.example .env      # puis adaptez-le (facultatif en local)
npm start                 # http://localhost:3000
```

Au **premier lancement**, un compte administrateur est créé et affiché dans le terminal (e-mail et mot de passe). Pour choisir vous-même : définissez `ADMIN_EMAIL` et `ADMIN_PASSWORD` dans `.env` *avant* le premier démarrage. Connexion : `/admin`. Changez ensuite le mot de passe dans **Mon compte**.

`npm test` lance 68 vérifications automatiques (pages, formulaires, anti-spam, envoi de CV, sécurité, administration).

## Mise en ligne

> **GitHub ne peut pas héberger ce site tel quel** : GitHub Pages ne sert que des fichiers statiques, alors que SERVEA a besoin d'un serveur (formulaires, administration, base de données). GitHub sert ici à **stocker le code** ; l'hébergement se fait ailleurs.

**Option A : Render (le plus simple)** : créez un compte sur render.com, « New → Blueprint », choisissez ce dépôt GitHub : le fichier `render.yaml` configure tout (disque persistant inclus). Renseignez `SITE_URL`, `ADMIN_EMAIL` et `ADMIN_PASSWORD` quand c'est demandé. Le disque persistant demande une offre payante.

**Option B : Docker (tout hébergeur, VPS)** :

```bash
docker build -t servea .
docker run -d --name servea --restart unless-stopped -p 3000:3000 -v servea-data:/data \
  -e SITE_URL=https://www.votre-domaine.com -e ADMIN_EMAIL=vous@domaine.com -e ADMIN_PASSWORD='un-mot-de-passe-solide' servea
```

**Option C : VPS sans Docker** : installez Node 22, copiez le dépôt, créez `.env`, lancez `npm start` sous `systemd` ou `pm2`.

Dans tous les cas, placez le site **derrière HTTPS** (Caddy, Nginx + Let's Encrypt, ou le HTTPS fourni par l'hébergeur) et mettez `NODE_ENV=production` et `TRUST_PROXY=1`.

### Variables d'environnement

| Variable | Rôle |
|---|---|
| `SITE_URL` | Adresse publique (sans `/` final), utilisée pour le SEO (canonical, sitemap, hreflang) |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Compte créé au premier lancement |
| `DATA_DIR` | Dossier de la base, des images envoyées et des CV (**à mettre sur un disque persistant**) |
| `NODE_ENV=production` | Active HSTS et les cookies `Secure` |
| `TRUST_PROXY=1` | Derrière un proxy/HTTPS : récupère la vraie IP des visiteurs (anti-spam) |
| `NOTIFY_WEBHOOK_URL` | Facultatif : webhook (Slack, Discord, Make, Zapier…) prévenu à chaque devis, candidature ou message |
| `PORT`, `SESSION_SECRET` | Port d'écoute ; secret de session (généré automatiquement sinon) |

## Publier sur Vercel (version vitrine statique)

Vercel n'héberge pas de serveur Node avec base de données : sur Vercel, le dépôt publie une **version statique** du site public (toutes les pages FR/EN, avec le motion). **Les formulaires (devis, candidature, contact) et l'administration ne fonctionnent pas** dans cette version : un message « version de démonstration » s'affiche à l'envoi. Pour le site complet, utilisez Render ou un VPS (voir « Mise en ligne »).

1. Poussez ce dépôt sur GitHub (le dossier `static-export/` est déjà généré et versionné).
2. Sur vercel.com : **Add New → Project → Import** votre dépôt. Ne changez aucun réglage : `vercel.json` indique tout (aucune commande de build, dossier `static-export`).
3. **Deploy.** Le site est en ligne sur une adresse `*.vercel.app`. Domaine personnalisé : *Settings → Domains*.

**Après toute modification du site** (textes modifiés dans l'admin, nouvelle page, nouveau style), régénérez la version statique, puis poussez :

```bash
SITE_URL=https://www.votre-domaine.com npm run export:static
git add -A && git commit -m "Mise à jour du site statique" && git push
```

`SITE_URL` est facultatif ; il ajoute les balises SEO (canonical, hreflang, sitemap) avec votre adresse.

## À faire avant la publication (rien n'est publié sans votre validation)

Toutes les informations non fournies sont marquées **« À renseigner »** sur le site : rien n'a été inventé. Dans **Admin → Textes & coordonnées** :

- [ ] Adresse à Kinshasa, téléphone, e-mail professionnel, horaires
- [ ] Numéro WhatsApp (le bouton apparaît automatiquement)
- [ ] Liens des réseaux sociaux
- [ ] Google Maps : *Partager → Intégrer une carte*, copier l'adresse après `src="…"`
- [ ] Histoire de SERVEA, message et photographie du fondateur (aucune citation n'a été inventée)
- [ ] Mentions légales (forme juridique, RCCM / Id. nat. / NIF, hébergeur) et politique de confidentialité : **modèles à faire valider**
- [ ] Profils recherchés (**Admin → Profils recherchés**) : les intitulés viennent de la liste des prestations, les descriptions sont à compléter
- [ ] Prestations des pôles **Technical & Maintenance**, **Business Services** et **Events & Staffing** : seules celles de la plaquette ont un tarif ; les autres sont des catégories à détailler (**Admin → Services**)
- [ ] Google Analytics (identifiant `G-XXXXXXXXXX`) et Search Console (code de vérification)
- [ ] Remplacer les photos extraites de la plaquette par les originaux haute définition (Admin → Pôles / Services)
- [ ] Relire l'actualité d'exemple (brouillon non publié) avant de la publier

> **Tarifs** : ceux de la plaquette sont affichés en dollars (USD). Vous pouvez les masquer partout (case « Afficher les tarifs » dans les réglages) ou les modifier service par service.

## Sauvegardes

Tout ce qui compte est dans `DATA_DIR` : `servea.db` (contenu, devis, candidatures), `uploads/` (photos), `private/cv/` (CV des candidats, jamais accessibles publiquement).

```bash
npm run backup      # crée backups/AAAAMMJJ_HHMM/ ; à planifier chaque nuit (cron) puis à copier hors du serveur
```

Les données personnelles (candidatures, CV) sont sensibles : limitez l'accès à l'administration et utilisez un mot de passe solide.

## Sécurité en bref

Échappement automatique de tout contenu affiché, requêtes SQL paramétrées, en-têtes CSP / HSTS / X-Frame-Options, vérification des fichiers envoyés par leur contenu réel (images ; PDF/DOC/DOCX pour les CV, 5 Mo max.), anti-spam (champ piège, délai minimal, limitation par IP), refus des POST venant d'un autre site, export CSV protégé contre l'injection de formules.

## Structure du projet

```
server.js            serveur HTTP, fichiers statiques, sitemap, en-têtes de sécurité
lib/pages.js         pages publiques et formulaires
lib/admin.js         espace d'administration
lib/layout.js        en-tête, pied de page, SEO, icônes, routes FR/EN
lib/i18n.js          textes de l'interface FR / EN (ajouter une langue ici)
lib/settings.js      réglages modifiables depuis l'admin
lib/seed.js          contenu initial (plaquette + cahier des charges)
lib/db.js            schéma SQLite
public/              CSS, JS, images (logo, photos)
test/smoke.js        tests automatiques
docs/sources/        logo fourni (180 px) pour mémoire
```

## Logo et visuels

Le logo utilisé est le logo **Servea** de la plaquette, non modifié. Le fichier `LOGO.jpg` fourni (180 × 180 px, mention « 69 Global ») est trop petit pour le web et diffère du logo de la plaquette : il est conservé dans `docs/sources/`. Envoyez le logo en haute définition (idéalement SVG ou PNG transparent) pour le remplacer dans `public/img/logo.jpg`. Les photos proviennent de la plaquette ; vérifiez que vous disposez des droits pour le site.
