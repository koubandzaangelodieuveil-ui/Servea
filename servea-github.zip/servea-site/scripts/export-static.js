/* Export statique du site public (FR + EN) pour un hébergement sans serveur (Vercel, Netlify, GitHub Pages…).
   Usage : npm run export:static   (facultatif : SITE_URL=https://www.votre-domaine.com npm run export:static)
   Les formulaires et l'administration ont besoin du serveur Node : ils ne fonctionnent pas dans cette version. */
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, cpSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'static-export');
const PORT = 3999, base = `http://127.0.0.1:${PORT}`;
const dataDir = join(tmpdir(), 'servea-export-' + Date.now());

const server = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server.js'], {
  cwd: root, stdio: 'ignore',
  env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, NODE_ENV: 'development', ADMIN_EMAIL: 'export@example.com', ADMIN_PASSWORD: 'export-' + Math.random().toString(36).slice(2) },
});
const stop = () => { try { server.kill(); } catch {} rmSync(dataDir, { recursive: true, force: true }); };
process.on('exit', stop);

for (let i = 0; i < 50; i++) { try { if ((await fetch(base + '/healthz')).ok) break; } catch {} await new Promise((r) => setTimeout(r, 200)); }

const NOTE = `<script>(function(){var en=document.documentElement.lang==='en';var msg=en?'Demo version: the form is not active on this static site.':'Version de démonstration : le formulaire n’est pas actif sur ce site statique.';document.querySelectorAll('form.form').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();e.stopImmediatePropagation();var n=f.querySelector('.static-note');if(!n){n=document.createElement('p');n.className='static-note';n.setAttribute('role','status');n.style.cssText='background:#fff2d1;border:1px dashed #d98a00;color:#7a4b00;border-radius:10px;padding:.7rem 1rem;font-weight:600';f.appendChild(n)}n.textContent=msg;var b=f.querySelector('button[type=submit]');if(b){b.disabled=false;b.style.opacity=''}},true)})})();</script>`;

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
cpSync(join(root, 'public'), out, { recursive: true });
rmSync(join(out, 'css/admin.css'), { force: true }); rmSync(join(out, 'js/admin.js'), { force: true });

const sitemap = await (await fetch(base + '/sitemap.xml')).text();
const paths = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => new URL(m[1], base).pathname);
if (!paths.length) paths.push('/', '/en/');

async function save(p, file) {
  const html = (await (await fetch(base + p)).text()).replace('</body>', NOTE + '</body>');
  mkdirSync(dirname(join(out, file)), { recursive: true });
  writeFileSync(join(out, file), html);
}
let n = 0;
for (const p of new Set(paths)) {
  const file = p === '/' ? 'index.html' : p.endsWith('/') ? p.slice(1) + 'index.html' : p.slice(1) + '.html';
  await save(p, file); n++;
}
writeFileSync(join(out, '404.html'), (await (await fetch(base + '/page-introuvable-404')).text()).replace('</body>', NOTE + '</body>'));
for (const f of ['robots.txt', 'sitemap.xml']) { try { writeFileSync(join(out, f), await (await fetch(base + '/' + f)).text()); } catch {} }
console.log(`Export terminé : ${n} pages dans static-export/`);
stop(); process.exit(0);
